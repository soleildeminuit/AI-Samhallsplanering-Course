# Python-skript för hämtning från Boverkets kartserver (Totalt_reg)
# Hämtar samtliga features med pagination och bounding box-filter

import sys, subprocess, requests, json

for lib in ["requests", "pandas"]:
    subprocess.run([sys.executable, "-m", "pip", "install", lib, "-q"])

BASE_URL = "https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query"

params = {
    "where": "region='Storstäder'",
    "geometry": "600000,6540000,750000,6620000",
    "geometryType": "esriGeometryEnvelope",
    "inSR": "3006",
    "spatialRel": "esriSpatialRelIntersects",
    "returnGeometry": "true",
    "outFields": "*",
    "outSR": "4326",
    "resultRecordCount": 2000,
    "f": "geojson"
}

all_features = []
offset = 0

while True:
    params["resultOffset"] = offset
    response = requests.get(BASE_URL, params=params)
    data = response.json()
    features = data.get("features", [])
    if not features:
        break
    all_features.extend(features)
    offset += 2000
    print(f"Hämtade {len(features)} objekt (offset={offset})")

print(f"Totalt hämtade objekt: {len(all_features)}")
