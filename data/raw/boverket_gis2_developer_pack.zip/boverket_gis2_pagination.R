# R-skript för att hämta data från Boverkets kartserver (Totalt_reg)
# Hämtar alla poster med pagination och bounding box-filter (region='Storstäder')
# Kod skriven för robust körning i RStudio eller terminal

library(httr)
library(jsonlite)

base_url <- "https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query"

params <- list(
  where = "region='Storstäder'",
  geometry = "600000,6540000,750000,6620000",
  geometryType = "esriGeometryEnvelope",
  inSR = "3006",
  spatialRel = "esriSpatialRelIntersects",
  returnGeometry = "true",
  outFields = "*",
  outSR = "4326",
  resultRecordCount = 2000,
  f = "geojson"
)

offset <- 0
all_features <- list()

repeat {
  params$resultOffset <- offset
  res <- GET(base_url, query = params)
  data <- fromJSON(content(res, "text"))
  if (length(data$features) == 0) break
  all_features <- append(all_features, data$features)
  offset <- offset + 2000
  cat("Hämtade", length(data$features), "objekt (offset =", offset, ")
")
}

cat("Totalt hämtade objekt:", length(all_features), "\n")
