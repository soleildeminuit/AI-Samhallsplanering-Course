# Boverkets kartserver (GIS2) – Fullständig teknisk dokumentation (“Developer Pack”)

## 1. Översikt
Denna dokumentation är en **komplett teknisk snapshot** av Boverkets karttjänst *Bostadsbrist* på `https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/`.  
Syftet är att bevara **all känd kunskap, testade URL:er, metoder, fält, struktur, koordinatsystem, felkällor och kodexempel**.

---

## 2. Struktur och hierarki

### ArcGIS REST-struktur
- **Service-nivå:** `/arcgis/rest/services/Bostadsbrist`
- **FeatureServer:** varje dataset utgör ett lager (layer ID)
- **Query-endpoint:** `/FeatureServer/{layer_id}/query`
- **Metadata:** `/FeatureServer/{layer_id}?f=pjson`

Exempel:
```
https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26
https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query?where=1%3D1&outFields=*&f=geojson
https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26?f=pjson
```

---

## 3. Identifierade lager (Feature Layers)

| Namn | ID | Beskrivning | Testad URL |
|------|----|--------------|------------|
| Totalt_reg | 26 | Sammanlagd statistik för regioner | https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query?where=1%3D1&outFields=*&f=geojson |
| hhtyp_2023_reg | 0 | Hushållstyper per region | https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/hhtyp_2023_reg/FeatureServer/0/query?where=1%3D1&outFields=*&f=geojson |
| agegroup_2023_reg | 25 | Åldersgrupper per region | https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/agegroup_2023_reg/FeatureServer/25/query?where=1%3D1&outFields=*&f=geojson |
| bform_2023_reg | 24 | Boendeformer per region | https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/bform_2023_reg/FeatureServer/24/query?where=1%3D1&outFields=*&f=geojson |
| Omradestyp_reg | 0 | Områdestyp, t.ex. storstad eller landsbygd | https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Omradestyp_reg/FeatureServer/0/query?where=1%3D1&outFields=*&f=geojson |

---

## 4. Metadata och fältalias (Totalt_reg, ID 26)

Hämtat från `?f=pjson`. Aliasen används som etiketter i webbkartan.

| Fältnamn | Alias / Ledtext | Datatyp |
|-----------|----------------|----------|
| year | År | esriFieldTypeSmallInteger |
| region | Region | esriFieldTypeString |
| urval | Urval | esriFieldTypeString |
| boendeekonomi1_antal | 1. Boendeekonomi A | Integer |
| boendeekonomi2_antal | 2. Boendeekonomi B | Integer |
| trangbodda_antal | 3. Trångboddhet | Integer |
| trangboendeekonomi1_antal | 4. Ansträngd boendesituation A | Integer |
| trangboendeekonomi2_antal | 5. Ansträngd boendesituation B | Integer |
| upprepadeflytthh_antal | 6. Flyttfrekvens | Integer |
| hemmaboendebarn_antal | 7. Hemmaboende barn | Integer |
| aterkommande_antal | 8. Återkommande problem | Integer |
| antaltotalt | Antal totalt | Integer |
| kategori | Kategori | String |
| titel | Titel | String |
| kod | Kod | String |
| year_date | Datum | Date |
| boendeekonomi1_andel | Andel Boendeekonomi A | Double |
| trangbodda_andel | Andel Trångboddhet | Double |
| aterkommande_andel | Andel Återkommande problem | Double |

---

## 5. Koordinatsystem och spatiala relationer

- Intern SRID: **EPSG:3006 (SWEREF 99 TM)**
- Utdataprojektion (för GeoJSON): **EPSG:4326 (WGS84)**
- `geometryType`: `esriGeometryPolygon`
- `spatialRel`: `esriSpatialRelIntersects` (hämtar alla som korsar området)

Exempel:
```bash
geometry=600000,6540000,750000,6620000
geometryType=esriGeometryEnvelope
inSR=3006
outSR=4326
```

Skillnad:
- `Intersects` → objekt som överlappar (helt eller delvis)
- `Contains` → endast objekt som ligger helt inom boxen

---

## 6. Bounding box-exempel

### a) Hela Sverige
```bash
https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query?where=1%3D1&returnGeometry=true&outFields=*&outSR=4326&f=geojson
```

### b) Stockholm (EPSG:3006)
```bash
https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query?where=region='Storstäder'&geometry=600000,6540000,750000,6620000&geometryType=esriGeometryEnvelope&inSR=3006&spatialRel=esriSpatialRelIntersects&returnGeometry=true&outFields=*&outSR=4326&resultRecordCount=2000&f=geojson
```

---

## 7. Pagination

ArcGIS begränsar resultat till 2000 poster per query (`maxRecordCount`).
För att hämta allt används offset:

```bash
...?resultRecordCount=2000&resultOffset=0
...?resultRecordCount=2000&resultOffset=2000
```

Tjänsten stöder `supportsPagination=true`.

---

## 8. Kodexempel – Python

```python
import sys, subprocess, json, requests, pandas as pd

for lib in ["requests", "pandas"]:
    subprocess.run([sys.executable, "-m", "pip", "install", lib, "-q"])

BASE_URL = "https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query"

params = {
    "where": "region='Storstäder'",
    "geometry": "600000,6540000,750000,6620000",
    "geometryType": "esriGeometryEnvelope",
    "inSR": "3006",
    "spatialRel": "esriSpatialRelIntersects",
    "returnGeometry": "true",
    "outFields": "*",
    "outSR": "4326",
    "resultRecordCount": 2000,
    "f": "geojson"
}

all_features = []
offset = 0

while True:
    params["resultOffset"] = offset
    r = requests.get(BASE_URL, params=params)
    data = r.json()
    features = data.get("features", [])
    if not features:
        break
    all_features.extend(features)
    offset += 2000
    print(f"Hämtade {len(features)} objekt (offset={offset})")

print(f"Totalt hämtade objekt: {len(all_features)}")
```

---

## 9. Kodexempel – R

```r
library(httr)
library(jsonlite)

base_url <- "https://gis2.boverket.se/arcgis/rest/services/Bostadsbrist/Totalt_reg/FeatureServer/26/query"

params <- list(
  where = "region='Storstäder'",
  geometry = "600000,6540000,750000,6620000",
  geometryType = "esriGeometryEnvelope",
  inSR = "3006",
  spatialRel = "esriSpatialRelIntersects",
  returnGeometry = "true",
  outFields = "*",
  outSR = "4326",
  resultRecordCount = 2000,
  f = "geojson"
)

offset <- 0
all_features <- list()

repeat {
  params$resultOffset <- offset
  res <- GET(base_url, query = params)
  data <- fromJSON(content(res, "text"))
  if (length(data$features) == 0) break
  all_features <- append(all_features, data$features)
  offset <- offset + 2000
  cat("Hämtade", length(data$features), "objekt (offset =", offset, ")
")
}

cat("Totalt hämtade objekt:", length(all_features), "
")
```

---

## 10. Vanliga felkällor

| Problem | Orsak | Lösning |
|----------|--------|----------|
| Tomt svar | Bounding box utanför giltigt område | Kontrollera `geometry` och `inSR` |
| CRS-fel | Mismatch mellan EPSG:3006 och EPSG:4326 | Ange `inSR=3006` och `outSR=4326` |
| “Invalid URL” | Felaktig parameter-encoding | Kontrollera `'` och `%3D` |
| Tomma geometrier | Fel `spatialRel` | Byt till `esriSpatialRelIntersects` |
| Begränsad mängd data | 2000 limit | Använd `resultOffset` |
| Ogiltiga värden | Null i fält | Hantera NA/NULL i R eller pandas |

---

## 11. Regionklassificering

| Kod | Beskrivning |
|-----|--------------|
| 4 | Mindre stad/tätort |
| 14 | Pendlingskommun nära mindre tätort |
| 82 | Större stad |
| 103 | Pendlingskommun nära större stad |
| 732 | Storstäder |
| 1055 | Pendlingskommun nära storstad |

---

## 12. Rekommendationer för analys

- Arbeta alltid med **EPSG:4326** vid export till GeoJSON.
- Validera resultatets geometri innan visualisering.
- Lägg till `limit` (i applikationsnivå) om endast urval behövs.
- Fältalias bör användas för användarvänlig presentation.

---

## 13. Sammanfattning

Denna dokumentation beskriver **alla identifierade tekniska aspekter** av Boverkets *Bostadsbrist*-kartserver.  
Den är avsedd för **analys, reproduktion, utveckling och AI-integration** med full spårbarhet till fält, struktur och exempel.
